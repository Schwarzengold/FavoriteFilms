import "./styles.css";

import React from "react";
import MovieList from "./MovieList";

function App() {
  const movies = [
    {
      id: 1,
      title: "The Green Elephant",
      director: "Svetlana Baskova",
      year: "1999",
      studio: "Warner Bros.",
      poster: "https://upload.wikimedia.org/wikipedia/ru/3/34/%D0%97%D0%B5%D0%BB%D1%91%D0%BD%D1%8B%D0%B9_%D1%81%D0%BB%D0%BE%D0%BD%D0%B8%D0%BA.jpg",

    },

    {
      id: 2,
      title: "Interstellar",
      director: "Christopher Nolan",
      year: 2014,
      studio: "Paramount Pictures",
      poster: "https://m.media-amazon.com/images/I/A1JVqNMI7UL._AC_UF894,1000_QL80_.jpg",
    },

    {
      id: 3,
      title: "Forrest Gump",
      director: "Robert Zemeckis",
      year: 1994,
      studio: "Paramount Pictures",
      poster:
        "https://image.tmdb.org/t/p/original/saHP97rTPS5eLmrLQEcANmKrsFl.jpg",
    },
    {
      id: 4,
      title: "The Godfather",
      director: "Francis Ford Coppola",
      year: 1972,
      studio: "Paramount Pictures",
      poster:
        "https://image.tmdb.org/t/p/original/3bhkrj58Vtu7enYsRolD1fZdja1.jpg",
    },
  ];

  return (
    <div className="App">
      <h1>Favorite Movies</h1>
      <MovieList movies={movies} />
    </div>
  );
}

export default App;
